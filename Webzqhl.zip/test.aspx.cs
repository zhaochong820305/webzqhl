﻿using System;
using System.Collections.Generic;
 
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using MySql.Data;
//using MySql.Data.MySqlClient;

public partial class test : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string constr = "server=localhost;User Id=root;password=123456;Database=test";
        //MySqlConnection mycon = new MySqlConnection(constr);
        //mycon.Open();
        //MySqlCommand mycmd = new MySqlCommand("select * from test", mycon);
        //if (mycmd.ExecuteNonQuery() > 0)
        //{
        //    Console.WriteLine("数据插入成功！");
        //}
        //Console.ReadLine();
        //mycon.Close();
    }
}