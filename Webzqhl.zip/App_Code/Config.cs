﻿using System;
using System.Collections.Generic;
 
using System.Web;

/// <summary>
/// Config 的摘要说明
/// </summary>
public class Config
{
    public static string PATH = AppDomain.CurrentDomain.BaseDirectory.ToString();
    public Config()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
}